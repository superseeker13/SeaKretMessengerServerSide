package javaHandler;

/**
 *
 * @author Daniel
 */

public class Account {
    private String username, email, password;
    
    public Account(String e, String u, String p){
        email = e;
        username = u;
        password = p;   
    }
    
      public String getEmail(){
        return email;
    }
    
    public String getUsername(){
        return username;
    }
    
    public String getPassword(){
        return password;
    }
    
    public void setPassword(String pass)
    {
        password = pass;
    }
    
    public String toString()
    {
        StringBuffer B = new StringBuffer();
        B.append("\tEmail: " + email + "\n");
	B.append("\tUsername: " + username + "\n");
        B.append("\tPassword: " + password + "\n");
	return B.toString();
    }
    
    public String toStringFile()
	{
		StringBuffer B = new StringBuffer();
		B.append(email + ",");
		B.append(username + ",");
                B.append(password);
		return B.toString();
	}
}